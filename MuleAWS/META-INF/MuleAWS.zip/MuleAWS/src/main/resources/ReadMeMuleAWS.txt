# MULEAWS
Sending messages using Mule AWS[amazon webservices] SQS[Simple Queue Service] and Creating/saving objects using AWS S3[Simple Storage Service]
Mule3.8 Sending messages using Mule AWS[amazon webservices] SQS[Simple Queue Service] and Creating/saving objects using AWS S3[Simple Storage Service]
--------------
Mule3.8 Sending messages using Mule AWS[amazon webservices] SQS[Simple Queue Service] and Creating/saving objects using AWS S3[Simple Storage Service]


This project 
---------
Sending messages using Mule AWS[amazon webservices] SQS[Simple Queue Service] and Creating/saving objects using AWS S3[Simple Storage Service]



Mule components
---------
1.File
2.Dataweave
3.Amazon S3CreateObject and S3GetObject
4.Amazon SQS send message and SQS get message
5.For-each
6.Database
7.http
8.Java component
9.Context property place folders
10.Message Properties transformer
11.VM Inbound/Outbound
12.Object-to-String
13.Exception Strategies




To Run
-------
Run as mule server or deploy into the mule sever as Mule Deployable Archive war,  by copy into the mule-standalone/apps


Technologies
---------
- J2E
- MySQL
- MULE ESB 3.8
- SaaS{Salesforce 7.2.0}
- Maven
